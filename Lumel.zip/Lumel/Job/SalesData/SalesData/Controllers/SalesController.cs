using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesData.Data;
using SalesData.Services;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;

[Route("[controller]")]
[ApiController]
public class SalesController : ControllerBase
{
    private readonly SalesDbContext _context;
    private readonly ISalesService _salesService;
    public SalesController(SalesDbContext context, ISalesService salesService)
    {
        _context = context;
        _salesService = salesService;
    }

    [HttpGet]
    [Route("/Sales")]
    [AllowAnonymous]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [SwaggerOperation("GetSales")]
    [SwaggerResponse(statusCode: 200, description: "GetSalesInfo", type: typeof(ProductResponse))]
    public async Task<IActionResult> GetSales([FromQuery][Required] DateTime From, [FromQuery][Required] DateTime To,
        [FromQuery] EnumHelpers.Category ByCategory, [FromQuery] EnumHelpers.Region ByRegion)
    {
        try
        {
            var result = await _salesService.GetTopNProducts(From, To, ByCategory, ByRegion);
            return StatusCode((int)result.StatusCode, result.Value);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
        }
    }


}

