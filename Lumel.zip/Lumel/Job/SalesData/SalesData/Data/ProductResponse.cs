﻿using System.Text.Json.Serialization;

namespace SalesData.Data
{
    public class ProductResponse
    {
        [JsonPropertyName("OverAllQuantity")]
        public int NumberOfProducts { get; set; }

        [JsonPropertyName("StartDate")]
        public DateTime DateFrom { get; set; }

        [JsonPropertyName("EndDate")]
        public DateTime DateTo { get; set; }
    }
}
