﻿
using Microsoft.EntityFrameworkCore;

namespace SalesData.Data
{
    public class SalesDbContext : DbContext
    {
        public DbSet<SalesData> SalesData { get; set; }

        public SalesDbContext(DbContextOptions<SalesDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SalesData>(entity =>
            {
                entity.ToTable("SalesData", "dbo");
                entity.HasKey(e => e.OrderID); // ✅ Sets OrderID as Primary Key
                entity.Property(e => e.OrderID).HasColumnName("OrderID");
                entity.Property(e => e.ProductID).HasColumnName("ProductID");
                entity.Property(e => e.Category).HasColumnName("Category");
                entity.Property(e => e.QuantitySold).HasColumnName("QuantitySold");
                entity.Property(e => e.PaymentMethod).HasColumnName("PaymentMethod");
                entity.Property(e => e.CustomerAddress).HasColumnName("CustomerAddress");
                entity.Property(e => e.CustomerEmail).HasColumnName("CustomerEmail");
                entity.Property(e => e.CustomerID).HasColumnName("CustomerID");
                entity.Property(e => e.CustomerName).HasColumnName("CustomerName");
                entity.Property(e => e.ProductName).HasColumnName("ProductName");
                entity.Property(e => e.UnitPrice).HasColumnName("UnitPrice");
                entity.Property(e => e.Region).HasColumnName("Region");
                entity.Property(e => e.DateOfSale).HasColumnName("DateOfSale");
                entity.Property(e => e.Discount).HasColumnName("Discount");


            });

        }
    }

}