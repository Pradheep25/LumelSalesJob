﻿using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace SalesData.Data
{
    public class EnumHelpers
    {

        public enum Region
        {
            None = 0,
            [EnumMember(Value = "North America")]
            NorthAmerica,
            [EnumMember(Value = "Europe")]
            Europe,
            [EnumMember(Value = "Asia")]
            Asia,
            [EnumMember(Value = "South America")]
            SouthAmerica
        }

        public enum Category
        {
            None = 0,
            Shoes,
            Electronics,
            Clothing
        }
    }
}
