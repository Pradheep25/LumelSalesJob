﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Extensions;
using SalesData.Data;
using System.Net;

namespace SalesData.Services
{
    public class SalesService : ISalesService
    {
        private readonly SalesDbContext _context;
        private readonly IConfiguration _configuration;

        public SalesService(SalesDbContext dbContext, IConfiguration configuration)
        {
            _context = dbContext;
            _configuration = configuration;
        }

        public async Task<ObjectResult> GetTopNProducts(DateTime From, DateTime To, EnumHelpers.Category ByCategory, EnumHelpers.Region ByRegion)
        {

            var res = await _context.SalesData.Where(x => x.DateOfSale >= From && x.DateOfSale <= To).ToListAsync().ConfigureAwait(false);

            if (ByCategory != 0 && ByRegion != 0)
            {
                res = res.Where(x => x.Category == ByCategory.GetDisplayName() && x.Region == ByRegion.GetDisplayName()).ToList();
            }
            else if (ByCategory != 0 || ByRegion != 0)

            {
                res = ByCategory != 0 ? res.Where(x => x.Category == ByCategory.GetDisplayName()).ToList() : res.Where(x => x.Region == ByRegion.GetDisplayName()).ToList();
            }
            var response = new ProductResponse()
            {
                NumberOfProducts = res.Select(x => x.QuantitySold).Sum(),
                DateFrom = From,
                DateTo = To
            };

            return new ObjectResult(response) { StatusCode = (int)HttpStatusCode.OK, Value = response };
        }
    }
}
