﻿
using Microsoft.AspNetCore.Mvc;
using SalesData.Data;

namespace SalesData.Services
{
    public interface ISalesService
    {
        public Task<ObjectResult> GetTopNProducts(DateTime From, DateTime To, EnumHelpers.Category ByCategory, EnumHelpers.Region ByRegion);
    }
}
